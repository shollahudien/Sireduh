@extends('layouts.admin')
@section('page-title', 'Dashboard')

@push('head')
<style>
    @media (min-width: 1024px) {
        html, body { height: 100%; overflow: hidden; }
        body > div.min-h-screen { height: 100vh !important; overflow: hidden; }
        main { overflow: hidden !important; min-height: 0; }
    }
    @media (max-width: 1023.98px) {
        main { min-height: 0; }
    }
</style>
@endpush

@section('content')
<style>
    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes floatSoft {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-3px); }
    }
    @keyframes pulseSoft {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: .45; transform: scale(1.4); }
    }
    .anim-fade-up { opacity: 0; animation: fadeUp .55s ease-out forwards; }
    .anim-float { animation: floatSoft 4s ease-in-out infinite; }
    .anim-pulse-soft { animation: pulseSoft 1.8s ease-in-out infinite; }
</style>
<div class="flex h-full min-h-0 flex-col gap-3 sm:gap-4 lg:overflow-hidden">
    {{-- Header --}}
    <div class="anim-fade-up flex shrink-0 flex-wrap items-end justify-between gap-3" style="animation-delay: 0ms;">
        <div>
            <p class="text-[11px] font-semibold uppercase tracking-[0.2em] text-green-700">Ringkasan Operasional</p>
            <h1 class="mt-0.5 text-xl font-bold text-gray-900 sm:text-2xl">Dashboard</h1>
            <p class="mt-0.5 text-xs text-gray-500 sm:text-sm">SIRESTEDUH · BUMDes Wisata Teduh · analitik 30 hari terakhir</p>
        </div>
        <div class="flex items-center gap-2 text-xs font-medium">
            <span class="inline-flex items-center gap-1.5 rounded-full border border-green-200 bg-green-50 px-2.5 py-1 text-green-800"><span class="anim-pulse-soft h-1.5 w-1.5 rounded-full bg-green-500"></span> Sistem aktif</span>
            <span class="rounded-full border border-gray-200 bg-white px-2.5 py-1 text-gray-600">{{ now()->format('d M Y') }}</span>
        </div>
    </div>

    {{-- Stat cards --}}
    <div class="grid shrink-0 grid-cols-2 gap-2 sm:gap-3 lg:grid-cols-4 lg:gap-4">
        @php
            $stats = [
                ['label' => 'Total Reservasi', 'value' => \App\Models\Reservation::count(), 'icon' => '📋', 'accent' => 'text-green-800', 'ring' => 'ring-green-100', 'bg' => 'bg-green-50'],
                ['label' => 'Menunggu Verifikasi', 'value' => \App\Models\Reservation::where('status', 'waiting_verification')->count(), 'icon' => '⏳', 'accent' => 'text-amber-700', 'ring' => 'ring-amber-100', 'bg' => 'bg-amber-50'],
                ['label' => 'Unit Sewa', 'value' => \App\Models\Unit::count(), 'icon' => '🏕️', 'accent' => 'text-teal-700', 'ring' => 'ring-teal-100', 'bg' => 'bg-teal-50'],
                ['label' => 'Pengguna Terdaftar', 'value' => \App\Models\User::count(), 'icon' => '👥', 'accent' => 'text-indigo-700', 'ring' => 'ring-indigo-100', 'bg' => 'bg-indigo-50'],
            ];
        @endphp
        @foreach($stats as $i => $s)
            <div class="anim-fade-up rounded-xl border border-gray-200 bg-white p-3 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md sm:p-4" style="animation-delay: {{ 80 + ($i * 70) }}ms;">
                <div class="flex items-start justify-between gap-2">
                    <div class="min-w-0">
                        <p class="truncate text-[11px] font-medium text-gray-500 sm:text-xs">{{ $s['label'] }}</p>
                        <p class="mt-1 text-xl font-bold tabular-nums {{ $s['accent'] }} sm:mt-1.5 sm:text-2xl">{{ number_format($s['value']) }}</p>
                    </div>
                    <span class="anim-float flex h-9 w-9 shrink-0 items-center justify-center rounded-lg {{ $s['bg'] }} text-base ring-1 {{ $s['ring'] }} sm:h-10 sm:w-10" style="animation-delay: {{ $i * 300 }}ms;">{{ $s['icon'] }}</span>
                </div>
            </div>
        @endforeach
    </div>

    {{-- Analytics + Revenue --}}
    <div class="grid min-h-0 flex-1 grid-cols-1 gap-3 sm:gap-4 xl:grid-cols-3 lg:overflow-hidden">
        {{-- Chart panel --}}
        <div class="anim-fade-up flex min-h-0 flex-col rounded-xl border border-gray-200 bg-white p-3 shadow-sm transition-shadow duration-300 hover:shadow-md sm:p-4 xl:col-span-2 lg:overflow-hidden" style="animation-delay: 380ms;">
            <div class="flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-2.5 sm:pb-3">
                <div>
                    <h2 class="text-sm font-bold text-gray-800 sm:text-base">Tren Analitik</h2>
                    <p class="text-[11px] text-gray-500 sm:text-xs">Pengunjung, penjualan, dan pendapatan (30 hari)</p>
                </div>
                <div class="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] font-medium text-gray-600 sm:text-[11px]">
                    <span class="inline-flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-sky-500"></span>Pengunjung</span>
                    <span class="inline-flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-emerald-500"></span>Penjualan</span>
                    <span class="inline-flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-amber-500"></span>Online</span>
                    <span class="inline-flex items-center gap-1.5"><span class="h-2 w-2 rounded-full bg-fuchsia-500"></span>Offline</span>
                </div>
            </div>

            <div class="mt-2 grid shrink-0 grid-cols-2 gap-2 text-[11px] sm:mt-3 sm:grid-cols-4 sm:gap-3 sm:text-xs">
                <div class="rounded-lg border border-gray-100 bg-gray-50/70 p-2 sm:p-2.5">
                    <p class="text-gray-500">Pengunjung</p>
                    <p class="mt-0.5 text-base font-bold tabular-nums text-gray-900 sm:text-lg" id="tot-visitors">0</p>
                </div>
                <div class="rounded-lg border border-gray-100 bg-gray-50/70 p-2 sm:p-2.5">
                    <p class="text-gray-500">Penjualan</p>
                    <p class="mt-0.5 text-base font-bold tabular-nums text-gray-900 sm:text-lg" id="tot-sales">0</p>
                </div>
                <div class="rounded-lg border border-amber-100 bg-amber-50/60 p-2 sm:p-2.5">
                    <p class="truncate text-amber-700">Pendapatan Online</p>
                    <p class="mt-0.5 truncate text-sm font-bold tabular-nums text-amber-800 sm:text-base" id="tot-online">Rp 0</p>
                </div>
                <div class="rounded-lg border border-fuchsia-100 bg-fuchsia-50/60 p-2 sm:p-2.5">
                    <p class="truncate text-fuchsia-700">Pendapatan Offline</p>
                    <p class="mt-0.5 truncate text-sm font-bold tabular-nums text-fuchsia-800 sm:text-base" id="tot-offline">Rp 0</p>
                </div>
            </div>

            <div class="relative mt-2 min-h-[220px] flex-1 sm:mt-3 sm:min-h-[260px] lg:min-h-0">
                <canvas id="analyticsChart"></canvas>
            </div>
        </div>

        {{-- Revenue breakdown --}}
        <div class="anim-fade-up flex min-h-0 flex-col rounded-xl border border-gray-200 bg-white p-3 shadow-sm transition-shadow duration-300 hover:shadow-md sm:p-4 lg:overflow-hidden" style="animation-delay: 460ms;">
            <div class="flex shrink-0 items-center justify-between gap-2 border-b border-gray-100 pb-2.5 sm:pb-3">
                <div>
                    <h2 class="text-sm font-bold text-gray-800 sm:text-base">Rincian Pendapatan</h2>
                    <p class="text-[11px] text-gray-500 sm:text-xs">Online & offline per kasir (30 hari)</p>
                </div>
            </div>

            <div class="mt-2 shrink-0 rounded-lg border border-green-100 bg-green-50/70 p-2.5 sm:mt-3 sm:p-3">
                <p class="text-[11px] font-medium uppercase tracking-wide text-green-700">Total Pendapatan</p>
                <p id="tot-all-revenue" class="mt-0.5 text-lg font-extrabold tabular-nums text-green-900 sm:text-xl">Rp 0</p>
            </div>

            <div class="mt-2 shrink-0 rounded-lg border border-amber-100 bg-amber-50/60 p-2.5 sm:mt-3">
                <div class="flex items-center justify-between gap-2">
                    <p class="text-xs font-semibold text-amber-800 sm:text-sm">Online (Reservasi)</p>
                    <p id="rev-online-total" class="text-sm font-bold tabular-nums text-amber-900 sm:text-base">Rp 0</p>
                </div>
                <p class="mt-0.5 text-[11px] text-amber-700/80">Akumulasi reservasi online non-batal.</p>
            </div>

            <div class="mt-2 flex min-h-0 flex-1 flex-col rounded-lg border border-gray-100 bg-gray-50/50 p-2.5 sm:mt-3">
                <div class="flex shrink-0 items-center justify-between gap-2">
                    <p class="text-xs font-semibold text-gray-800 sm:text-sm">Offline (POS/Kasir)</p>
                    <p id="rev-offline-total" class="text-sm font-bold tabular-nums text-fuchsia-700 sm:text-base">Rp 0</p>
                </div>
                <div class="mt-2 grid shrink-0 grid-cols-3 gap-1.5 text-[10px] sm:gap-2 sm:text-[11px]">
                    <div class="rounded-md border border-green-100 bg-white p-1.5 sm:p-2">
                        <p class="font-medium text-green-700">Tunai</p>
                        <p id="rev-offline-cash" class="mt-0.5 font-bold tabular-nums text-gray-900">Rp 0</p>
                        <p class="text-[10px] text-gray-400"><span id="rev-offline-cash-count">0</span> trx</p>
                    </div>
                    <div class="rounded-md border border-blue-100 bg-white p-1.5 sm:p-2">
                        <p class="font-medium text-blue-700">QRIS</p>
                        <p id="rev-offline-qris" class="mt-0.5 font-bold tabular-nums text-gray-900">Rp 0</p>
                        <p class="text-[10px] text-gray-400"><span id="rev-offline-qris-count">0</span> trx</p>
                    </div>
                    <div class="rounded-md border border-indigo-100 bg-white p-1.5 sm:p-2">
                        <p class="font-medium text-indigo-700">Transfer</p>
                        <p id="rev-offline-transfer" class="mt-0.5 font-bold tabular-nums text-gray-900">Rp 0</p>
                        <p class="text-[10px] text-gray-400"><span id="rev-offline-transfer-count">0</span> trx</p>
                    </div>
                </div>
                <div class="mt-2 min-h-0 flex-1 overflow-auto lg:max-h-none">
                    <table class="w-full text-left text-[11px] sm:text-xs">
                        <thead class="sticky top-0 bg-gray-50 text-gray-500">
                            <tr class="border-b border-gray-200">
                                <th class="py-1.5 pr-2 font-semibold">Kasir</th>
                                <th class="py-1.5 pr-2 text-right font-semibold">Trx</th>
                                <th class="py-1.5 text-right font-semibold">Pendapatan</th>
                            </tr>
                        </thead>
                        <tbody id="cashier-revenue-body" class="divide-y divide-gray-100 text-gray-700">
                            <tr><td colspan="3" class="py-2 text-gray-400">Memuat...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
(async function () {
    try {
        const res = await fetch('/api/admin/dashboard-analytics', { headers: { 'Accept': 'application/json' } });
        const data = await res.json();
        if (!data || !data.labels) return;

        const fmt = (v) => 'Rp ' + Math.round(v || 0).toLocaleString('id-ID');
        document.getElementById('tot-visitors').textContent = (data.totals?.visitors ?? 0).toLocaleString('id-ID');
        document.getElementById('tot-sales').textContent = (data.totals?.sales ?? 0).toLocaleString('id-ID');
        document.getElementById('tot-online').textContent = fmt(data.totals?.online_revenue ?? 0);
        document.getElementById('tot-offline').textContent = fmt(data.totals?.offline_revenue ?? 0);
        document.getElementById('tot-all-revenue').textContent = fmt(data.totals?.total_revenue ?? ((data.totals?.online_revenue ?? 0) + (data.totals?.offline_revenue ?? 0)));
        document.getElementById('rev-online-total').textContent = fmt(data.totals?.online_revenue ?? 0);
        document.getElementById('rev-offline-total').textContent = fmt(data.totals?.offline_revenue ?? 0);

        const methods = Array.isArray(data.offline_by_method) ? data.offline_by_method : [];
        const byMethod = Object.fromEntries(methods.map((m) => [m.method, m]));
        ['cash', 'qris', 'transfer'].forEach((key) => {
            const row = byMethod[key] || { total_amount: 0, transactions: 0 };
            document.getElementById(`rev-offline-${key}`).textContent = fmt(row.total_amount ?? 0);
            document.getElementById(`rev-offline-${key}-count`).textContent = (row.transactions ?? 0).toLocaleString('id-ID');
        });

        const cashierBody = document.getElementById('cashier-revenue-body');
        const cashiers = Array.isArray(data.offline_by_cashier) ? data.offline_by_cashier : [];
        if (cashiers.length === 0) {
            cashierBody.innerHTML = '<tr><td colspan="3" class="py-2 text-gray-400">Belum ada transaksi offline pada periode ini.</td></tr>';
        } else {
            cashierBody.innerHTML = cashiers.map((c) => {
                const name = String(c.name ?? '-').replace(/</g, '&lt;');
                const role = String(c.role ?? '').replace(/</g, '&lt;');
                const label = role ? `${name} <span class="text-gray-400">(${role})</span>` : name;
                return `<tr><td class="py-1.5 pr-2 font-medium text-gray-800">${label}</td><td class="py-1.5 pr-2 text-right tabular-nums">${(c.transactions ?? 0).toLocaleString('id-ID')}</td><td class="py-1.5 text-right font-semibold tabular-nums text-fuchsia-700">${fmt(c.total_amount ?? 0)}</td></tr>`;
            }).join('');
        }

        const ctx = document.getElementById('analyticsChart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    { label: 'Pengunjung', data: data.visitors, borderColor: '#0ea5e9', backgroundColor: 'rgba(14,165,233,0.08)', yAxisID: 'yCount', tension: 0.35, fill: true, pointRadius: 2, pointHoverRadius: 4 },
                    { label: 'Penjualan', data: data.sales, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.08)', yAxisID: 'yCount', tension: 0.35, fill: true, pointRadius: 2, pointHoverRadius: 4 },
                    { label: 'Online', data: data.online_revenue, borderColor: '#f59e0b', backgroundColor: 'rgba(245,158,11,0.08)', yAxisID: 'yMoney', tension: 0.35, fill: true, pointRadius: 2, pointHoverRadius: 4 },
                    { label: 'Offline', data: data.offline_revenue, borderColor: '#d946ef', backgroundColor: 'rgba(217,70,239,0.08)', yAxisID: 'yMoney', tension: 0.35, fill: true, pointRadius: 2, pointHoverRadius: 4 },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: { duration: 900, easing: 'easeOutQuart' },
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#111827',
                        titleColor: '#f9fafb',
                        bodyColor: '#e5e7eb',
                        padding: 10,
                        cornerRadius: 8,
                    },
                },
                scales: {
                    x: { ticks: { color: '#6b7280', font: { size: 10 }, maxRotation: 0, autoSkip: true, maxTicksLimit: 10 }, grid: { color: 'rgba(17,24,39,0.06)' } },
                    yCount: { type: 'linear', position: 'left', beginAtZero: true, title: { display: true, text: 'Jumlah', color: '#6b7280', font: { size: 10 } }, ticks: { color: '#6b7280', font: { size: 10 } }, grid: { color: 'rgba(17,24,39,0.06)' } },
                    yMoney: { type: 'linear', position: 'right', beginAtZero: true, title: { display: true, text: 'Rupiah', color: '#6b7280', font: { size: 10 } }, grid: { drawOnChartArea: false }, ticks: { color: '#6b7280', font: { size: 10 }, callback: (v) => 'Rp ' + Math.round(v).toLocaleString('id-ID') } },
                },
            },
        });

        let offset = 0;
        (function flow() {
            offset -= 0.6;
            chart.data.datasets.forEach((d) => {
                d.borderDash = [6, 4];
                d.borderDashOffset = offset;
            });
            chart.update('none');
            requestAnimationFrame(flow);
        })();

        async function refreshAnalytics() {
            try {
                const r = await fetch('/api/admin/dashboard-analytics', { headers: { 'Accept': 'application/json' } });
                const d = await r.json();
                if (!d || !d.labels) return;
                chart.data.labels = d.labels;
                chart.data.datasets[0].data = d.visitors;
                chart.data.datasets[1].data = d.sales;
                chart.data.datasets[2].data = d.online_revenue;
                chart.data.datasets[3].data = d.offline_revenue;
                chart.update();
                document.getElementById('tot-visitors').textContent = (d.totals?.visitors ?? 0).toLocaleString('id-ID');
                document.getElementById('tot-sales').textContent = (d.totals?.sales ?? 0).toLocaleString('id-ID');
                document.getElementById('tot-online').textContent = fmt(d.totals?.online_revenue ?? 0);
                document.getElementById('tot-offline').textContent = fmt(d.totals?.offline_revenue ?? 0);
                document.getElementById('tot-all-revenue').textContent = fmt(d.totals?.total_revenue ?? ((d.totals?.online_revenue ?? 0) + (d.totals?.offline_revenue ?? 0)));
                document.getElementById('rev-online-total').textContent = fmt(d.totals?.online_revenue ?? 0);
                document.getElementById('rev-offline-total').textContent = fmt(d.totals?.offline_revenue ?? 0);
                const ms = Array.isArray(d.offline_by_method) ? d.offline_by_method : [];
                const bm = Object.fromEntries(ms.map((m) => [m.method, m]));
                ['cash', 'qris', 'transfer'].forEach((key) => {
                    const row = bm[key] || { total_amount: 0, transactions: 0 };
                    document.getElementById(`rev-offline-${key}`).textContent = fmt(row.total_amount ?? 0);
                    document.getElementById(`rev-offline-${key}-count`).textContent = (row.transactions ?? 0).toLocaleString('id-ID');
                });
                const body = document.getElementById('cashier-revenue-body');
                const cs = Array.isArray(d.offline_by_cashier) ? d.offline_by_cashier : [];
                if (cs.length === 0) {
                    body.innerHTML = '<tr><td colspan="3" class="py-2 text-gray-400">Belum ada transaksi offline pada periode ini.</td></tr>';
                } else {
                    body.innerHTML = cs.map((c) => {
                        const name = String(c.name ?? '-').replace(/</g, '&lt;');
                        const role = String(c.role ?? '').replace(/</g, '&lt;');
                        const label = role ? `${name} <span class="text-gray-400">(${role})</span>` : name;
                        return `<tr><td class="py-1.5 pr-2 font-medium text-gray-800">${label}</td><td class="py-1.5 pr-2 text-right tabular-nums">${(c.transactions ?? 0).toLocaleString('id-ID')}</td><td class="py-1.5 text-right font-semibold tabular-nums text-fuchsia-700">${fmt(c.total_amount ?? 0)}</td></tr>`;
                    }).join('');
                }
            } catch (e) {}
        }
        setInterval(refreshAnalytics, 15000);
    } catch (e) {
        console.error('analytics load failed', e);
    }
})();
</script>
@endsection
