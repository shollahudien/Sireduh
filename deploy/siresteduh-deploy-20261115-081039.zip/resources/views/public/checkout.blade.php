@extends('layouts.app')

@section('title', 'Checkout')

@section('content')
<div x-data="checkoutPage()" x-init="init()">

    {{-- Success panel --}}
    <div x-show="success" x-cloak class="max-w-2xl mx-auto">
        <div class="bg-white rounded-2xl shadow border border-green-100 p-8 md:p-12 text-center">
            <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-6">✅</div>
            <h1 class="text-2xl md:text-3xl font-extrabold text-green-900 mb-2">Pesanan Berhasil Dibuat!</h1>
            <p class="text-gray-500 mb-6">Simpan kode pesanan berikut. Anda akan diarahkan ke pembayaran transfer.</p>
            <div class="bg-green-50 border border-green-200 rounded-xl py-4 px-6 inline-block mb-6">
                <p class="text-xs uppercase tracking-widest text-green-700 font-semibold">Order Code</p>
                <p class="text-2xl md:text-3xl font-mono font-bold text-green-900" x-text="success?.order_code"></p>
            </div>
            <div class="text-sm text-gray-600 mb-8">
                <span class="font-semibold">Total:</span>
                <span x-text="formatIDR(lastTotal)"></span>
            </div>
            <div class="flex flex-col sm:flex-row gap-3 justify-center">
                <a :href="'/pembayaran/' + success?.order_code"
                   class="bg-green-700 text-white font-bold px-8 py-3.5 rounded-xl hover:bg-green-800 transition shadow-lg shadow-green-700/20 inline-flex items-center justify-center gap-2">
                    Lanjut ke Pembayaran →
                </a>
                <button @click="resetAll()" class="border border-gray-200 text-gray-600 font-semibold px-8 py-3.5 rounded-xl hover:bg-gray-50 transition">
                    Buat Pesanan Lagi
                </button>
            </div>
            <p class="text-xs text-gray-400 mt-4">
                Dialihkan otomatis ke halaman pembayaran dalam beberapa detik…
                <button type="button" @click="cancelAutoRedirect()" class="text-green-700 font-semibold hover:underline">Batalkan</button>
            </p>
        </div>
    </div>

    {{-- Main layout --}}
    <div x-show="!success" x-cloak>
        {{-- Page header --}}
        <div class="mb-6">
            <span class="inline-flex items-center gap-2 text-[10px] sm:text-[11px] font-bold uppercase tracking-[0.16em] text-green-700 bg-green-50 ring-1 ring-green-100 rounded-full px-3 py-1.5 mb-3">
                <span class="tech-dot w-2 h-2 rounded-full bg-green-500"></span>
                Pemesanan Real-time
            </span>
            <h1 class="text-2xl sm:text-3xl font-extrabold text-green-900">Checkout</h1>
            <p class="text-gray-500 mt-1 text-sm sm:text-base">Sewa glamping / aula / alat wisata, atau beli Tiket Masuk saja.</p>
            <div class="h-1 w-24 sm:w-32 mt-3 rounded-full bg-gradient-to-r from-lime-400 via-emerald-400 to-teal-400"></div>
        </div>

        <div class="grid lg:grid-cols-3 gap-6 items-start">

            {{-- ============ LEFT: form ============ --}}
            <div class="lg:col-span-2 space-y-6">

                {{-- Tabs --}}
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-2 grid grid-cols-2 gap-2">
                    <button type="button" @click="tab = 'unit'"
                        :class="tab === 'unit' ? 'bg-green-700 text-white shadow' : 'text-gray-600 hover:bg-green-50'"
                        class="px-4 py-3 rounded-xl font-semibold transition flex flex-col items-center gap-0.5">
                        <span>🏕️ Sewa Unit</span>
                        <span class="text-xs font-normal opacity-80">Glamping / Aula / Alat</span>
                    </button>
                    <button type="button" @click="switchTab('tiket')"
                        :class="tab === 'tiket' ? 'bg-green-700 text-white shadow' : 'text-gray-600 hover:bg-green-50'"
                        class="px-4 py-3 rounded-xl font-semibold transition flex flex-col items-center gap-0.5">
                        <span>🎫 Tiket Masuk Saja</span>
                        <span class="text-xs font-normal opacity-80">Tanpa menginap</span>
                    </button>
                </div>

                {{-- Error banner --}}
                <div x-show="errorMessage" x-cloak class="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm flex items-start gap-2">
                    <span>⚠️</span><span x-text="errorMessage"></span>
                </div>

                {{-- ===== TAB: Sewa Unit ===== --}}
                <div x-show="tab === 'unit'" x-cloak class="space-y-5">

                    {{-- Date selection --}}
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <label class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Tanggal Menginap</label>
                            <span x-show="nights > 0 || (isPackagedUnit() && selectedPackage)" x-cloak class="inline-flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-[11px] font-semibold text-green-800 ring-1 ring-green-100">
                                <span x-text="(isPackagedUnit() && selectedPackage) ? (selectedPackage.duration_hours + ' jam') : (nights + ' malam')"></span>
                                <template x-if="checkIn && checkOut"><span class="font-medium text-green-700/80" x-text="'· ' + formatDateShort(checkIn) + ' – ' + formatDateShort(checkOut)"></span></template>
                            </span>
                        </div>
                        <div class="mt-2 flex flex-wrap gap-1.5">
                            <button type="button" @click="setStayToday()" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Hari Ini</button>
                            <button type="button" @click="setStayTomorrow()" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Besok</button>
                            <button type="button" @click="setStayWeekend()" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Akhir Pekan</button>
                        </div>
                        <div class="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                            <div class="rounded-xl border border-gray-200 bg-gray-50/60 p-2.5">
                                <label class="text-[11px] font-semibold uppercase tracking-wide text-gray-500" x-text="(isPackagedUnit() && selectedPackage) ? 'Tanggal Mulai' : 'Tanggal Check-in'"></label>
                                <div class="mt-1">
                                    <input id="check_in" type="date" x-model="checkIn" :min="todayStr" @change="onCheckInChange()"
                                           class="w-full rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-600">
                                </div>
                                <p class="mt-1 text-[11px] text-gray-500" x-show="!(isPackagedUnit() && selectedPackage)" x-text="checkIn ? formatDateLong(checkIn) : 'Pilih tanggal check-in'"></p>
                                <p class="mt-1 text-[11px] text-gray-500" x-show="isPackagedUnit() && selectedPackage" x-cloak>Jam mulai & selesai menyesuaikan saat check-in/scan (durasi sesuai paket).</p>
                            </div>
                            <div class="rounded-xl border border-gray-200 bg-gray-50/60 p-2.5" x-show="!(isPackagedUnit() && selectedPackage)">
                                <label class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tanggal Check-out</label>
                                <div class="mt-1">
                                    <input id="check_out" type="date" x-model="checkOut" :min="minCheckout || todayStr" @change="fetchAvailability()"
                                           class="w-full rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-600">
                                </div>
                                <p class="mt-1 text-[11px] text-gray-500" x-text="checkOut ? formatDateLong(checkOut) : 'Pilih tanggal check-out'"></p>
                            </div>
                            <div class="rounded-xl border border-green-100 bg-green-50/70 p-2.5" x-show="isPackagedUnit() && selectedPackage" x-cloak>
                                <label class="text-[11px] font-semibold uppercase tracking-wide text-green-800">Durasi Paket</label>
                                <p class="mt-1 text-sm font-semibold text-green-900" x-text="selectedPackage ? (selectedPackage.duration_hours + ' jam (mulai saat check-in/scan)') : '-' "></p>
                                <p class="mt-1 text-[11px] text-green-700">Cukup pilih tanggal; waktu aktual mengikuti saat petugas melakukan scan check-in.</p>
                            </div>
                        </div>
                        <p x-show="dateInvalid" x-cloak class="mt-2 text-xs font-medium text-red-600">Tanggal check-out harus sama atau setelah tanggal check-in.</p>
                        <p x-show="!dateInvalid" x-cloak class="mt-2 text-xs text-gray-500">Cukup pilih tanggal & paket. Jam mulai menyesuaikan saat check-in/scan; ketersediaan dicek per tanggal (aula 1 unit, glamping 6 unit per jadwal).</p>
                    </div>

                    {{-- Availability results --}}
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                        <div class="flex items-center justify-between gap-3 flex-wrap">
                            <h2 class="font-bold text-gray-800">Unit Tersedia</h2>
                            <div class="flex gap-1.5 text-xs">
                                <template x-for="f in unitTypeFilters" :key="f.value">
                                    <button type="button" @click="setUnitType(f.value)"
                                        :class="unitType === f.value ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'"
                                        class="px-3 py-1.5 rounded-full font-medium transition" x-text="f.label"></button>
                                </template>
                            </div>
                        </div>

                        <div x-show="unitType === 'glamping' || unitType === 'aula' || isPackagedUnit()" x-cloak class="mt-4 rounded-xl border border-amber-200 bg-amber-50/60 p-3">
                            <p class="text-[11px] font-semibold uppercase tracking-wide text-amber-800">Paket <span x-text="selectedUnit?.type === 'aula' || unitType === 'aula' ? 'Aula' : 'Glamping'"></span></p>
                            <select x-model="selectedPackageId" @change="onPackageChange()" class="mt-2 w-full rounded-xl border border-amber-200 bg-white px-3 py-2.5 text-sm font-semibold text-gray-800 focus:outline-none focus:ring-2 focus:ring-green-600">
                                <option value="">-- Pilih paket --</option>
                                <template x-for="pkg in (selectedUnit?.type === 'aula' ? aulaPackages : (selectedUnit?.type === 'glamping' ? glampingPackages : (unitType === 'aula' ? aulaPackages : (unitType === 'glamping' ? glampingPackages : currentPackages()))))" :key="pkg.id">
                                    <option :value="pkg.id" x-text="pkg.name + ' — ' + pkg.duration_hours + ' jam — ' + formatIDR(pkg.price)"></option>
                                </template>
                            </select>
                            <div class="mt-2 rounded-xl border border-amber-100 bg-white px-3 py-2.5 text-sm text-gray-700">
                                <span x-show="!selectedPackage" class="text-gray-400">Pilih paket, lalu tentukan tanggal & jam mulai.</span>
                                <span x-show="selectedPackage" x-cloak><span class="font-semibold" x-text="selectedPackage ? (selectedPackage.name + ' (' + selectedPackage.duration_hours + ' jam)') : ''"></span> · selesai otomatis: <span class="font-semibold" x-text="checkOut ? (formatDateShort(checkOut) + ' ' + checkOutTime) : '-' "></span></span>
                            </div>
                            <p class="mt-1.5 text-[11px] text-amber-800/80">Booking berbasis paket/jam dan dicek per jadwal; jika slot penuh, jadwal tidak bisa dipesan.</p>
            <div x-show="(selectedUnit?.type === 'glamping' || unitType === 'glamping') && selectedPackageId && glampingRemainingSlots !== null" x-cloak
                 class="mt-2 rounded-lg px-3 py-2 text-xs font-semibold"
                 :class="glampingRemainingSlots > 0 ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'">
                <template x-if="glampingRemainingSlots > 0"><span>Slot glamping tersedia: <span x-text="glampingRemainingSlots"></span> dari 6.</span></template>
                <template x-if="glampingRemainingSlots <= 0"><span>Glamping penuh pada jadwal ini (6/6 terisi). Pilih tanggal/jam atau paket lain.</span></template>
            </div>
                        </div>

                        {{-- Loading spinner --}}
                        <div x-show="loadingUnits" x-cloak class="flex items-center gap-3 text-gray-400 py-10 justify-center">
                            <svg class="animate-spin h-6 w-6 text-green-700" viewBox="0 0 24 24" fill="none">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                            </svg>
                            <span>Memeriksa ketersediaan...</span>
                        </div>

                        {{-- Error state --}}
                        <div x-show="unitsError && !loadingUnits" x-cloak class="text-center text-red-600 text-sm py-8" x-text="unitsError"></div>

                        {{-- Prompt to pick dates first --}}
                        <div x-show="!loadingUnits && !checkIn && !unitsError" x-cloak class="text-center text-gray-400 py-10">
                            <div class="text-4xl mb-2">📅</div>
                            Pilih tanggal untuk melihat unit/paket tersedia.
                        </div>

                        {{-- Empty state --}}
                        <div x-show="!loadingUnits && filteredUnits.length === 0 && checkIn && !unitsError" x-cloak
                             class="text-center text-gray-400 py-10">
                            <div class="text-4xl mb-2">😔</div>
                            Tidak ada unit tersedia untuk tanggal &amp; tipe ini.
                        </div>

                        {{-- Unit cards --}}
                        <div class="grid sm:grid-cols-2 gap-4 mt-4">
                            <template x-for="unit in filteredUnits" :key="unit.id">
                                <button type="button" @click="selectUnit(unit)"
                                    :disabled="unit.type === 'glamping' && glampingRemainingSlots !== null && glampingRemainingSlots <= 0"
                                    :class="unit.type === 'glamping' && glampingRemainingSlots !== null && glampingRemainingSlots <= 0 ? 'opacity-60 cursor-not-allowed border-red-200 bg-red-50/40' : (selectedUnit?.id === unit.id ? 'ring-2 ring-green-600 border-green-600 bg-green-50' : 'border-gray-200 hover:border-green-400')"
                                    class="text-left border rounded-2xl p-4 transition bg-white relative">
                                    <span x-show="selectedUnit?.id === unit.id" x-cloak
                                          class="absolute top-3 right-3 bg-green-600 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center">✓</span>
                                    <div class="relative h-28 -mx-4 -mt-4 mb-3 overflow-hidden rounded-t-2xl bg-green-50">
                                        <template x-if="unit.images?.length">
                                            <img :src="unit.images?.[0]?.url" :alt="unit.name" class="w-full h-full object-cover">
                                        </template>
                                        <div x-show="!unit.images?.length" x-cloak class="absolute inset-0 flex items-center justify-center text-4xl" x-text="typeEmoji(unit.type)"></div>
                                        <span class="absolute top-2 left-2 text-[10px] font-bold rounded-full px-2 py-0.5"
                                              :class="unit.type === 'glamping' && glampingRemainingSlots !== null && glampingRemainingSlots <= 0 ? 'bg-red-600 text-white' : 'bg-black/55 text-white'"
                                              x-text="unit.type === 'glamping' && glampingRemainingSlots !== null ? (glampingRemainingSlots <= 0 ? 'Penuh (6/6)' : 'Sisa ' + glampingRemainingSlots + '/6') : ('Sisa ' + unit.stock)"></span>
                                    </div>
                                    <h3 class="font-bold text-gray-800 leading-snug" x-text="unit.name"></h3>
                                    <p class="text-xs text-gray-400 mt-0.5">
                                        <span x-text="typeLabel(unit.type)"></span> · Kapasitas <span x-text="unit.capacity"></span> orang · Sisa <span x-text="unit.stock"></span>
                                    </p>
                                    <p class="text-green-700 font-bold mt-2">
                                        <template x-if="(unit.type === 'glamping' || unit.type === 'aula') && selectedPackage"><span><span x-text="formatIDR(selectedPackage.price)"></span><span class="text-xs font-medium text-gray-400"> / paket</span></span></template>
                                        <template x-if="!((unit.type === 'glamping' || unit.type === 'aula') && selectedPackage)"><span><span x-text="formatIDR(unit.price)"></span><span class="text-xs font-medium text-gray-400" x-text="(unit.type === 'glamping' || unit.type === 'aula') ? ' / paket' : ' / malam'"></span></span></template>
                                    </p>
                                </button>
                            </template>
                        </div>
                    </div>
                </div>

                {{-- ===== TAB: Tiket Masuk Saja ===== --}}
                <div x-show="tab === 'tiket'" x-cloak class="space-y-5">
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <h2 class="font-bold text-gray-800">Tiket Masuk</h2>
                            <span class="text-xs text-gray-400">Berlaku sesuai tanggal kunjungan</span>
                        </div>

                        <div class="mt-3 rounded-xl border border-gray-200 bg-gray-50/60 p-3">
                            <label for="visit_date" class="text-[11px] font-semibold uppercase tracking-wide text-gray-500">Tanggal Kunjungan</label>
                            <div class="mt-2 flex flex-wrap gap-1.5">
                                <button type="button" @click="setVisitOffset(0)" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Hari Ini</button>
                                <button type="button" @click="setVisitOffset(1)" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Besok</button>
                                <button type="button" @click="setVisitWeekend()" class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 transition hover:border-green-300 hover:text-green-700">Akhir Pekan</button>
                            </div>
                            <div class="mt-2">
                                <input id="visit_date" type="date" x-model="checkIn" :min="todayStr" @change="onVisitDateChange()"
                                       class="w-full rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-600">
                            </div>
                            <p class="mt-1.5 text-[11px] text-gray-500">Tiket masuk berlaku penuh 1 hari sesuai tanggal kunjungan.</p>
                            <p class="mt-1 inline-flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-[11px] font-semibold text-green-800 ring-1 ring-green-100" x-show="checkIn" x-cloak>
                                <span x-text="formatDateLong(checkIn) + ' · Seharian (full 1 hari)'"></span>
                            </p>
                        </div>

                        <div x-show="loadingTickets" x-cloak class="flex items-center gap-3 text-gray-400 py-8 justify-center">
                            <svg class="animate-spin h-6 w-6 text-green-700" viewBox="0 0 24 24" fill="none">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                            </svg>
                            <span>Memuat tiket...</span>
                        </div>

                        <div class="grid sm:grid-cols-2 gap-4 mt-4">
                            <template x-for="ticket in tickets" :key="ticket.id">
                                <div class="border border-gray-200 rounded-2xl p-4 hover:border-green-400 transition bg-white">
                                    <div class="relative h-24 -mx-4 -mt-4 mb-2 overflow-hidden rounded-t-2xl bg-amber-50 cursor-pointer" @click="openDetail(ticket, 'tiket')" title="Lihat detail produk">
                                    <template x-if="ticket.images?.length">
                                        <img :src="ticket.images?.[0]?.url" :alt="ticket.name" class="w-full h-full object-cover">
                                    </template>
                                    <div x-show="!ticket.images?.length" x-cloak class="absolute inset-0 flex items-center justify-center text-4xl">🎫</div>
                                    <span x-show="ticket.images?.length > 1" x-cloak
                                          class="absolute bottom-1.5 right-1.5 bg-black/55 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">📷 <span x-text="ticket.images.length"></span></span>
                                </div>
                                    <h3 class="font-bold text-gray-800 leading-snug cursor-pointer hover:text-green-700" @click="openDetail(ticket, 'tiket')" x-text="ticket.name"></h3>
                                    <button type="button" @click="openDetail(ticket, 'tiket')"
                                            class="mt-1 text-xs font-semibold text-green-700 hover:underline">🔍 Lihat Detail &amp; Foto</button>
                                    <p class="text-xs text-gray-400 mt-0.5">Sisa stok: <span x-text="ticket.stock"></span></p>
                                    <p class="text-green-700 font-bold mt-2" x-text="formatIDR(ticket.price)"></p>
                                    <div class="flex items-center justify-between mt-3">
                                        <div class="flex items-center border border-gray-200 rounded-lg">
                                            <button type="button" class="px-3 py-1.5 text-gray-500 hover:text-green-700" @click="decTicketQty(ticket)">−</button>
                                            <span class="w-8 text-center font-semibold" x-text="ticketQty(ticket.id)"></span>
                                            <button type="button" class="px-3 py-1.5 text-gray-500 hover:text-green-700" @click="incTicketQty(ticket)">+</button>
                                        </div>
                                        <button type="button" @click="addTicket(ticket)"
                                                class="bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-green-800 transition">
                                            Tambah
                                        </button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>

                {{-- ===== UMKM / Add-on strip (semua tab) ===== --}}
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
                    <div class="flex items-center justify-between mb-3">
                        <h2 class="font-bold text-gray-800">Tambahan UMKM &amp; Add-on</h2>
                        <span class="text-xs text-gray-400">Opsional</span>
                    </div>
                    <div x-show="loadingAddons" x-cloak class="text-gray-400 text-sm py-4">Memuat produk UMKM...</div>
                    <div class="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
                        <template x-for="addon in addons" :key="addon.id">
                            <div class="shrink-0 w-40 border border-gray-200 rounded-2xl p-3 flex flex-col">
                                <div class="relative h-20 -mx-3 -mt-3 mb-2 overflow-hidden rounded-t-2xl bg-amber-50 cursor-pointer" @click="openDetail(addon, 'addon')" title="Lihat detail produk">
                                    <template x-if="addon.images?.length">
                                        <img :src="addon.images?.[0]?.url" :alt="addon.name" class="w-full h-full object-cover">
                                    </template>
                                    <div x-show="!addon.images?.length" x-cloak class="absolute inset-0 flex items-center justify-center text-xl" x-text="categoryEmoji(addon.category)"></div>
                                    <span x-show="addon.images?.length > 1" x-cloak
                                          class="absolute bottom-1 right-1 bg-black/55 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">📷 <span x-text="addon.images.length"></span></span>
                                </div>
                                <h3 class="text-sm font-semibold text-gray-800 leading-snug line-clamp-2 min-h-10 cursor-pointer hover:text-green-700" @click="openDetail(addon, 'addon')" x-text="addon.name"></h3>
                                <button type="button" @click="openDetail(addon, 'addon')"
                                        class="mt-0.5 text-[11px] font-semibold text-green-700 hover:underline self-start">🔍 Detail &amp; Foto</button>
                                <p class="text-green-700 font-bold text-sm mt-1.5" x-text="formatIDR(addon.price)"></p>
                                <button type="button" @click="addToCart(addon)"
                                        :disabled="addon.stock <= 0"
                                        :class="addon.stock <= 0 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-green-50 text-green-800 hover:bg-green-100'"
                                        class="mt-auto pt-2 mx-auto w-full text-xs font-bold py-1.5 rounded-lg transition">
                                    <span x-text="addon.stock <= 0 ? 'Habis' : '+ Tambah'"></span>
                                </button>
                            </div>
                        </template>
                        <p x-show="!loadingAddons && addons.length === 0" x-cloak class="text-sm text-gray-400 py-4">Belum ada produk UMKM.</p>
                    </div>
                </div>
            </div>

            {{-- ============ RIGHT: trigger ringkasan ============ --}}
            <div class="lg:col-span-1">
                <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 lg:sticky lg:top-6"
                     x-show="itemCount > 0" x-cloak
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 translate-y-2"
                     x-transition:enter-end="opacity-100 translate-y-0">
                    <h2 class="font-extrabold text-lg text-green-900 flex items-center justify-between">
                        Ringkasan Pesanan
                        <span class="text-xs font-semibold bg-green-100 text-green-800 rounded-full px-3 py-1" x-text="itemCount + ' item'"></span>
                    </h2>

                    <ul class="mt-3 space-y-1.5 text-sm">
                        <li x-show="selectedUnit" class="flex justify-between gap-2 text-gray-600">
                            <span class="truncate" x-text="selectedUnit?.name"></span>
                            <span class="font-semibold shrink-0" x-text="formatIDR(unitSubtotal)"></span>
                        </li>
                        <template x-for="item in cart" :key="item.id">
                            <li class="flex justify-between gap-2 text-gray-600">
                                <span class="truncate"><span x-text="item.qty + '×'"></span> <span x-text="item.name"></span></span>
                                <span class="font-semibold shrink-0" x-text="formatIDR(item.price * item.qty)"></span>
                            </li>
                        </template>
                    </ul>

                    <div class="flex justify-between items-baseline border-t border-gray-100 mt-3 pt-3">
                        <span class="font-bold text-gray-800">Total</span>
                        <span class="text-xl font-extrabold text-green-800" x-text="formatIDR(grandTotal)"></span>
                    </div>

                    <button type="button" @click="openCheckout()"
                            class="w-full mt-4 bg-green-700 text-white font-bold py-3.5 rounded-xl hover:bg-green-800 shadow-lg shadow-green-700/20 transition flex items-center justify-center gap-2">
                        Lanjutkan ke Pemesanan <span aria-hidden="true">→</span>
                    </button>
                    <p class="text-[11px] text-gray-400 text-center mt-2">Ringkasan &amp; Data Pemesan dibuka di modal.</p>
                </div>

                {{-- Placeholder sebelum produk dipilih --}}
                <div x-show="itemCount === 0" x-cloak
                     x-transition:enter="transition ease-out duration-200"
                     x-transition:enter-start="opacity-0 translate-y-2"
                     x-transition:enter-end="opacity-100 translate-y-0"
                     class="bg-white rounded-2xl shadow-sm border border-dashed border-gray-200 p-6 text-center text-gray-500 lg:sticky lg:top-6">
                    <div class="text-4xl mb-2">🧺</div>
                    <p class="font-bold text-gray-600">Belum ada produk dipilih</p>
                    <p class="text-sm mt-1.5 leading-relaxed">Pilih unit, tiket, atau tambahan UMKM — <span class="font-semibold">Ringkasan Pesanan</span> &amp; <span class="font-semibold">Data Pemesan</span> akan muncul di modal.</p>
                </div>
            </div>
        </div>
    </div>

    {{-- ===== Detail produk publik: galeri foto (mendukung 3+ gambar) ===== --}}
    <div x-show="detailOpen" x-cloak class="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4" @keydown.escape.window="closeDetail()">
        <div class="absolute inset-0 bg-black/60" @click="closeDetail()"></div>
        <div x-show="detailOpen" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0"
             class="relative bg-white w-full sm:max-w-lg sm:rounded-2xl rounded-t-2xl overflow-hidden max-h-[92vh] flex flex-col shadow-2xl">
            <div class="flex items-start justify-between gap-3 px-5 py-4 border-b border-gray-100 shrink-0">
                <div class="min-w-0">
                    <p class="text-[10px] uppercase tracking-wider text-gray-400 font-bold" x-text="categoryLabel(detailProduct?.category)"></p>
                    <h3 class="font-extrabold text-gray-800 leading-snug" x-text="detailProduct?.name ?? ''"></h3>
                </div>
                <button type="button" @click="closeDetail()" aria-label="Tutup detail"
                        class="text-gray-400 hover:text-gray-700 text-2xl leading-none shrink-0">×</button>
            </div>

            <div class="overflow-y-auto">
                {{-- Galeri utama --}}
                <div class="relative bg-amber-50">
                    <div class="relative aspect-[4/3] overflow-hidden flex items-center justify-center">
                        <template x-if="detailImages.length">
                            <img :src="detailImages[detailImageIndex]?.url" :alt="detailProduct?.name"
                                 class="w-full h-full object-contain">
                        </template>
                        <div x-show="detailImages.length === 0" x-cloak class="text-6xl" x-text="categoryEmoji(detailProduct?.category)"></div>
                    </div>

                    <button type="button" x-show="detailImages.length > 1" x-cloak @click.stop="prevDetailImage()" aria-label="Foto sebelumnya"
                            class="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 shadow-md flex items-center justify-center text-gray-700 text-xl leading-none hover:bg-white transition">‹</button>
                    <button type="button" x-show="detailImages.length > 1" x-cloak @click.stop="nextDetailImage()" aria-label="Foto berikutnya"
                            class="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 shadow-md flex items-center justify-center text-gray-700 text-xl leading-none hover:bg-white transition">›</button>

                    <span x-show="detailImages.length > 1" x-cloak
                          class="absolute top-2 right-2 bg-black/55 text-white text-[11px] font-bold px-2 py-0.5 rounded-full"
                          x-text="(detailImageIndex + 1) + ' / ' + detailImages.length"></span>
                </div>

                {{-- Thumbnail: semua foto (termasuk 3 atau lebih) --}}
                <div x-show="detailImages.length > 1" x-cloak class="flex gap-2 overflow-x-auto px-5 py-3 border-b border-gray-100">
                    <template x-for="(img, i) in detailImages" :key="img.id">
                        <button type="button" @click="detailImageIndex = i"
                                :class="i === detailImageIndex ? 'ring-2 ring-green-600 border-transparent opacity-100' : 'border-gray-200 opacity-60 hover:opacity-100'"
                                class="shrink-0 w-16 h-16 rounded-lg overflow-hidden border bg-gray-50 transition">
                            <img :src="img.url" :alt="img.alt || detailProduct?.name" class="w-full h-full object-cover">
                        </button>
                    </template>
                </div>

                <div class="px-5 py-4 space-y-3">
                    <div class="flex items-center justify-between gap-3">
                        <p class="text-xl font-extrabold text-green-800" x-text="formatIDR(detailProduct?.price)"></p>
                        <span class="text-xs font-bold rounded-full px-2.5 py-1 shrink-0"
                              :class="(detailProduct?.stock ?? 0) > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'"
                              x-text="(detailProduct?.stock ?? 0) > 0 ? ('Stok: ' + detailProduct.stock) : 'Habis'"></span>
                    </div>

                    <div x-show="detailKind === 'tiket'" class="flex items-center justify-between">
                        <span class="text-sm text-gray-500">Jumlah tiket</span>
                        <div class="flex items-center border border-gray-200 rounded-lg">
                            <button type="button" class="px-3 py-1.5 text-gray-500 hover:text-green-700" @click="detailProduct && decTicketQty(detailProduct)">−</button>
                            <span class="w-8 text-center font-semibold" x-text="detailProduct ? ticketQty(detailProduct.id) : 0"></span>
                            <button type="button" class="px-3 py-1.5 text-gray-500 hover:text-green-700" @click="detailProduct && incTicketQty(detailProduct)">+</button>
                        </div>
                    </div>

                    <p x-show="detailImages.length > 1" class="text-xs text-gray-500">
                        📷 <span x-text="detailImages.length"></span> foto tersedia — klik thumbnail atau tombol ‹ › untuk melihat sisanya.
                    </p>
                    <p x-show="detailImages.length === 1" class="text-xs text-gray-500">📷 Hanya 1 foto tersedia untuk produk ini.</p>
                    <p x-show="detailImages.length === 0" x-cloak class="text-xs text-gray-500">Belum ada foto untuk produk ini.</p>
                </div>
            </div>

            <div class="px-5 py-4 border-t border-gray-100 flex gap-2 shrink-0">
                <button type="button" @click="closeDetail()"
                        class="flex-1 text-sm font-semibold text-gray-600 border border-gray-200 rounded-xl py-3 hover:bg-gray-50 transition">Tutup</button>
                <button type="button" @click="detailAdd()" :disabled="(detailProduct?.stock ?? 0) <= 0"
                        :class="(detailProduct?.stock ?? 0) <= 0 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-green-700 text-white hover:bg-green-800'"
                        class="flex-[2] text-sm font-bold rounded-xl py-3 transition"
                        x-text="(detailProduct?.stock ?? 0) <= 0 ? 'Stok Habis' : 'Tambah ke Keranjang'"></button>
            </div>
        </div>
    </div>

    {{-- ===== Modal: Ringkasan Pesanan & Data Pemesan ===== --}}
    <div x-show="checkoutOpen" x-cloak class="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4"
         @keydown.escape.window="closeCheckout()"
         x-effect="if (checkoutOpen && itemCount === 0) closeCheckout()">
        <div class="absolute inset-0 bg-black/60" @click="closeCheckout()"></div>
        <div x-show="checkoutOpen" x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0"
             class="relative bg-white w-full sm:max-w-xl sm:rounded-2xl rounded-t-2xl overflow-hidden max-h-[92vh] flex flex-col shadow-2xl">
            <div class="flex items-start justify-between gap-3 px-5 py-4 border-b border-gray-100 shrink-0">
                <div>
                    <h2 class="font-extrabold text-gray-800 text-lg leading-tight">Ringkasan Pesanan &amp; Data Pemesan</h2>
                    <p class="text-xs text-gray-400 mt-0.5"><span x-text="itemCount"></span> item dipilih</p>
                </div>
                <button type="button" @click="closeCheckout()" aria-label="Tutup"
                        class="text-gray-400 hover:text-gray-700 text-2xl leading-none shrink-0">×</button>
            </div>

            <div class="overflow-y-auto px-5 py-4 space-y-5">
                {{-- Ringkasan --}}
                <section>
                    <h3 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">🧾 Ringkasan</h3>

                    <template x-if="selectedUnit">
                        <div class="flex items-start gap-3 bg-green-50 border border-green-100 rounded-xl p-3">
                            <span class="text-2xl" x-text="typeEmoji(selectedUnit.type)"></span>
                            <div class="flex-1 min-w-0">
                                <p class="font-bold text-gray-800 text-sm leading-snug" x-text="selectedUnit.name"></p>
                                <p class="text-xs text-gray-500 mt-0.5" x-show="!(isPackagedUnit() && selectedPackage)"><span x-text="nights"></span> malam × <span x-text="formatIDR(selectedUnit.price)"></span></p>
                                <p class="text-xs text-gray-500 mt-0.5" x-show="isPackagedUnit() && selectedPackage" x-cloak x-text="selectedPackage ? (selectedPackage.name + ' · ' + selectedPackage.duration_hours + ' jam · mulai saat check-in/scan') : ''"></p>
                            </div>
                            <div class="text-right shrink-0">
                                <p class="text-sm font-bold text-green-800" x-text="formatIDR(unitSubtotal)"></p>
                                <button type="button" @click="selectedUnit = null" class="text-xs text-red-500 hover:text-red-700 mt-1">Hapus</button>
                            </div>
                        </div>
                    </template>

                    <ul class="divide-y divide-gray-100" :class="selectedUnit ? 'mt-3' : ''">
                        <template x-for="item in cart" :key="item.id">
                            <li class="py-3 flex items-center gap-3">
                                <span class="text-xl" x-text="categoryEmoji(item.category)"></span>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-semibold text-gray-800 leading-snug" x-text="item.name"></p>
                                    <p class="text-xs text-gray-400" x-text="formatIDR(item.price) + ' / item'"></p>
                                </div>
                                <div class="flex items-center border border-gray-200 rounded-lg text-xs shrink-0">
                                    <button type="button" class="px-2 py-1 text-gray-500 hover:text-green-700" @click="decCart(item)">−</button>
                                    <span class="w-6 text-center font-semibold" x-text="item.qty"></span>
                                    <button type="button" class="px-2 py-1 text-gray-500 hover:text-green-700" @click="incCart(item)">+</button>
                                </div>
                                <button type="button" @click="removeCart(item)" class="text-gray-300 hover:text-red-500 transition shrink-0" aria-label="Hapus item">✕</button>
                            </li>
                        </template>
                    </ul>

                    <div class="border-t border-gray-100 mt-2 pt-3 space-y-1.5 text-sm">
                        <div class="flex justify-between text-gray-500"><span>Unit</span><span x-text="formatIDR(unitSubtotal)"></span></div>
                        <div class="flex justify-between text-gray-500"><span>Tiket &amp; Add-on</span><span x-text="formatIDR(cartSubtotal)"></span></div>
                        <div class="flex justify-between items-baseline pt-2 border-t border-dashed border-gray-200">
                            <span class="font-bold text-gray-800">Total</span>
                            <span class="text-xl font-extrabold text-green-800" x-text="formatIDR(grandTotal)"></span>
                        </div>
                    </div>
                </section>

                {{-- Data Pemesan --}}
                <section>
                    <h3 class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">👤 Data Pemesan</h3>
                    <div class="grid sm:grid-cols-2 gap-3">
                        <div class="sm:col-span-2">
                            <label for="visitor_name" class="text-xs text-gray-400">Nama Lengkap *</label>
                            <input id="visitor_name" type="text" x-model="visitorName" placeholder="Budi Santoso" required
                                   class="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-green-600 focus:outline-none">
                        </div>
                        <div>
                            <label for="visitor_whatsapp" class="text-xs text-gray-400">No. WhatsApp *</label>
                            <input id="visitor_whatsapp" type="tel" inputmode="numeric" x-model="visitorWhatsapp" @input="sanitizeWhatsapp()"
                                   placeholder="081234567890" required
                                   class="mt-1 w-full border rounded-xl px-3 py-2.5 focus:ring-2 focus:outline-none"
                                   :class="visitorWhatsapp && !whatsappValid ? 'border-red-300 focus:ring-red-400' : 'border-gray-200 focus:ring-green-600'">
                            <p class="text-[11px] text-gray-400 mt-1" x-show="!visitorWhatsapp || whatsappValid">E-tiket QR dikirim ke nomor ini.</p>
                            <p class="text-[11px] text-red-600 mt-1 font-medium" x-show="visitorWhatsapp && !whatsappValid" x-cloak x-text="whatsappError()"></p>
                        </div>
                        <div>
                            <label for="visitor_email" class="text-xs text-gray-400">Email <span class="text-gray-300">(opsional)</span></label>
                            <input id="visitor_email" type="email" x-model="visitorEmail" placeholder="nama@email.com"
                                   class="mt-1 w-full border border-gray-200 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-green-600 focus:outline-none">
                        </div>
                    </div>
                </section>
            </div>

            <div class="px-5 py-4 border-t border-gray-100 shrink-0">
                <div x-show="errorMessage" x-cloak class="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-2.5 text-sm flex items-start gap-2 mb-3">
                    <span>⚠️</span><span x-text="errorMessage"></span>
                </div>
                <button type="button" @click="submit()" :disabled="!canSubmit || sending"
                        :class="!canSubmit || sending ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-green-700 text-white hover:bg-green-800 shadow-lg shadow-green-700/20'"
                        class="w-full font-bold py-3.5 rounded-xl transition flex items-center justify-center gap-2">
                    <svg x-show="sending" x-cloak class="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                    </svg>
                    <span x-text="sending ? 'Memproses...' : 'Pesan Sekarang — ' + formatIDR(grandTotal)"></span>
                </button>
                <p x-show="!canSubmit" x-cloak class="text-[11px] text-amber-600 font-medium text-center mt-2">
                <span x-text="tab === 'unit' ? ((selectedUnit && (selectedUnit.type === 'glamping' || selectedUnit.type === 'aula')) ? 'Lengkapi Nama & WhatsApp, pilih tanggal & paket, lalu pilih unit untuk melanjutkan.' : 'Lengkapi Nama & WhatsApp serta tanggal check-in dan check-out untuk melanjutkan.') : 'Lengkapi Nama & WhatsApp serta tanggal kunjungan untuk melanjutkan.'"></span>
            </p>
                <p class="text-[11px] text-gray-400 text-center mt-2">Pembayaran diverifikasi admin. E-tiket dikirim via WhatsApp setelah pembayaran disetujui.</p>
            </div>
        </div>
    </div>
</div>

<script>
function checkoutPage() {
    return {
        tab: 'unit',
        todayStr: '',
        checkIn: '',
        checkOut: '',
        checkInTime: '14:00',
        checkOutTime: '12:00',
        unitType: 'all',
        availableUnits: [],
        selectedUnit: null,
        selectedPackageId: '',
        glampingPackages: [],
        aulaPackages: [],
        glampingRemainingSlots: null,
        aulaRemainingSlots: null,
        loadingUnits: false,
        unitsError: '',
        tickets: [],
        ticketQuantities: {},
        loadingTickets: false,
        addons: [],
        loadingAddons: false,
        cart: [],
        visitorName: '',
        visitorWhatsapp: '',
        visitorEmail: '',
        sending: false,
        errorMessage: '',
        success: null,
        lastTotal: 0,
        redirectTimer: null,
        detailOpen: false,
        detailProduct: null,
        detailKind: 'addon',
        detailImageIndex: 0,
        checkoutOpen: false,

        unitTypeFilters: [
            { value: 'all', label: 'Semua' },
            { value: 'glamping', label: 'Glamping' },
            { value: 'aula', label: 'Aula' },
            { value: 'alat_wisata', label: 'Alat Wisata' },
        ],

        init() {
            // Tanggal minimal = hari ini menurut waktu venue (Asia/Jakarta),
            // konsisten dengan validasi backend.
            this.refreshToday();
            this.loadAddons();
            this.preloadPackages();
        },

        async preloadPackages() {
            try {
                this.refreshToday();
                const d = this.todayStr;
                const res = await fetch(`/api/availability?check_in=${d}&check_out=${d}&check_in_time=08:00&check_out_time=09:00`);
                const data = await res.json();
                if (Array.isArray(data.glamping_packages)) this.glampingPackages = data.glamping_packages;
                if (Array.isArray(data.aula_packages)) this.aulaPackages = data.aula_packages;
            } catch (e) {}
        },

        refreshToday() {
            this.todayStr = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta' }).format(new Date());
        },

        ensureDatesValid() {
            this.refreshToday();
            if (this.tab === 'unit') {
                if (this.checkIn && this.checkIn < this.todayStr) this.checkIn = this.todayStr;
                if (this.isPackagedUnit() && this.selectedPackageId) {
                    const end = this.computePackageEnd();
                    if (end) { this.checkOut = end.date; this.checkOutTime = end.time; }
                } else {
                    if (!this.checkOut || this.checkOut < this.checkIn) this.checkOut = this.checkIn || '';
                    if (this.checkIn && this.checkOut) {
                        const inDT = this.dateTimeValue(this.checkIn, this.checkInTime);
                        let outDT = this.dateTimeValue(this.checkOut, this.checkOutTime);
                        if (outDT <= inDT) {
                            if (this.checkOut === this.checkIn) {
                                this.checkOutTime = this.addHourStr(this.checkInTime, 1);
                            } else {
                                this.checkOut = this.checkIn;
                                this.checkOutTime = this.addHourStr(this.checkInTime, 1);
                            }
                        }
                    }
                }
            } else {
                if (this.checkIn && this.checkIn < this.todayStr) this.checkIn = this.todayStr;
                this.checkOut = this.checkIn || '';
                this.checkInTime = '00:00';
                this.checkOutTime = '23:59';
            }
        },

        dateTimeValue(d, t) {
            return new Date(`${d}T${(t || '00:00')}:00`).getTime();
        },

        addHourStr(t, h) {
            const [hh, mm] = (t || '00:00').split(':').map(Number);
            const dt = new Date(2000, 0, 1, hh + h, mm || 0);
            const H = String(Math.min(dt.getHours(), 23)).padStart(2, '0');
            const M = String(dt.getMinutes()).padStart(2, '0');
            return `${H}:${M}`;
        },

        dateFromStr(str) {
            const [y, m, d] = str.split('-').map(Number);
            return new Date(y, m - 1, d);
        },

        strFromDate(date) {
            const y = date.getFullYear();
            const m = String(date.getMonth() + 1).padStart(2, '0');
            const d = String(date.getDate()).padStart(2, '0');
            return `${y}-${m}-${d}`;
        },

        addDaysStr(str, days) {
            const dt = this.dateFromStr(str);
            dt.setDate(dt.getDate() + days);
            return this.strFromDate(dt);
        },

        formatDateShort(str) {
            if (!str) return '';
            return this.dateFromStr(str).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        },

        formatDateLong(str) {
            if (!str) return '';
            return this.dateFromStr(str).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
        },

        get minCheckout() {
            return this.checkIn || this.todayStr;
        },

        onCheckInChange() {
            this.ensureDatesValid();
            this.fetchAvailability();
        },

        setStayDates(inStr, outStr) {
            this.checkIn = inStr;
            this.checkOut = outStr;
            this.ensureDatesValid();
            this.fetchAvailability();
        },

        setStayToday() {
            this.setStayDates(this.todayStr, this.addDaysStr(this.todayStr, 1));
        },

        setStayTomorrow() {
            const inStr = this.addDaysStr(this.todayStr, 1);
            this.setStayDates(inStr, this.addDaysStr(inStr, 1));
        },

        setStayWeekend() {
            const base = this.dateFromStr(this.todayStr);
            const day = base.getDay(); // 0 Sun .. 6 Sat
            let daysToSat = (6 - day + 7) % 7;
            if (daysToSat === 0 && day === 6) daysToSat = 7; // if today is Sat, pick next weekend
            const sat = this.addDaysStr(this.todayStr, daysToSat);
            this.setStayDates(sat, this.addDaysStr(sat, 1));
        },

        onVisitDateChange() {
            this.ensureDatesValid();
        },

        setVisitOffset(days) {
            this.refreshToday();
            this.checkIn = this.addDaysStr(this.todayStr, days);
            this.ensureDatesValid();
        },

        setVisitWeekend() {
            const base = this.dateFromStr(this.todayStr);
            const day = base.getDay();
            let daysToSat = (6 - day + 7) % 7;
            if (daysToSat === 0 && day === 6) daysToSat = 7;
            this.setVisitOffset(daysToSat);
        },

        async switchTab(name) {
            this.tab = name;
            this.errorMessage = '';
            if (name === 'tiket') {
                this.checkInTime = '00:00';
                this.checkOutTime = '23:59';
                if (!this.checkIn) {
                    this.setVisitOffset(0);
                } else {
                    this.checkOut = this.checkIn;
                    this.ensureDatesValid();
                }
                if (this.tickets.length === 0) {
                    await this.loadTickets();
                }
            } else {
                if (this.checkInTime === '00:00') this.checkInTime = '14:00';
                if (this.checkOutTime === '23:59') this.checkOutTime = '12:00';
                this.ensureDatesValid();
            }
        },

        setUnitType(value) {
            this.unitType = value;
            if (value === 'glamping' || value === 'aula') {
                if (this.selectedUnit && this.selectedUnit.type !== value) this.selectedUnit = null;
                const pkgs = value === 'aula' ? this.aulaPackages : this.glampingPackages;
                if (!this.selectedPackageId || !pkgs.find(p => p.id === this.selectedPackageId)) {
                    this.selectedPackageId = pkgs[0]?.id || '';
                }
            } else if (value === 'alat_wisata') {
                this.selectedPackageId = '';
            }
            this.ensureDatesValid();
            this.fetchAvailability();
        },

        get filteredUnits() {
            if (this.unitType === 'all') return this.availableUnits;
            return this.availableUnits.filter(u => u.type === this.unitType);
        },

        isPackagedUnit() {
            return this.selectedUnit?.type === 'glamping' || this.selectedUnit?.type === 'aula';
        },

        currentPackages() {
            if (this.selectedUnit?.type === 'aula') return this.aulaPackages;
            if (this.selectedUnit?.type === 'glamping') return this.glampingPackages;
            if (this.unitType === 'aula') return this.aulaPackages;
            if (this.unitType === 'glamping') return this.glampingPackages;
            return [...(this.glampingPackages || []), ...(this.aulaPackages || [])];
        },

        get selectedPackage() {
            return this.currentPackages().find(p => p.id === this.selectedPackageId) || null;
        },

        computePackageEnd() {
            if (!this.checkIn || !this.checkInTime || !this.selectedPackage) return null;
            const start = new Date(`${this.checkIn}T${this.checkInTime}:00`);
            start.setHours(start.getHours() + Number(this.selectedPackage.duration_hours || 0));
            const y = start.getFullYear();
            const m = String(start.getMonth() + 1).padStart(2, '0');
            const d = String(start.getDate()).padStart(2, '0');
            const hh = String(start.getHours()).padStart(2, '0');
            const mm = String(start.getMinutes()).padStart(2, '0');
            return { date: `${y}-${m}-${d}`, time: `${hh}:${mm}` };
        },

        get nights() {
            if (this.isPackagedUnit() && this.selectedPackage) return 1;
            if (!this.checkIn || !this.checkOut) return 0;
            const diff = (new Date(this.checkOut) - new Date(this.checkIn)) / 86400000;
            return diff > 0 ? Math.ceil(diff) : 1;
        },

        get dateInvalid() {
            if (!this.checkIn || !this.checkInTime) return false;
            if (this.tab === 'unit' && this.isPackagedUnit() && this.selectedPackage) return false;
            if (!this.checkOut || !this.checkOutTime) return !!(this.checkIn && this.checkOut);
            return this.dateTimeValue(this.checkOut, this.checkOutTime) <= this.dateTimeValue(this.checkIn, this.checkInTime);
        },

        get unitSubtotal() {
            if (!this.selectedUnit) return 0;
            if (this.isPackagedUnit() && this.selectedPackage) return Number(this.selectedPackage.price);
            if (this.nights <= 0) return 0;
            return Number(this.selectedUnit.price) * this.nights;
        },

        get cartSubtotal() {
            return this.cart.reduce((sum, item) => sum + Number(item.price) * item.qty, 0);
        },

        get grandTotal() {
            return this.unitSubtotal + this.cartSubtotal;
        },

        get itemCount() {
            return (this.selectedUnit ? 1 : 0) + this.cart.reduce((sum, item) => sum + item.qty, 0);
        },

        get detailImages() {
            return this.detailProduct?.images ?? [];
        },

        // ===== Validasi nomor WhatsApp (mirror App\Rules\WhatsAppNumber) =====
        sanitizeWhatsapp() {
            // Hanya digit; '+' hanya boleh di awal. Maksimal 16 digit.
            const plus = this.visitorWhatsapp.trim().startsWith('+');
            let digits = this.visitorWhatsapp.replace(/\D/g, '');
            if (digits.length > 16) digits = digits.slice(0, 16);
            this.visitorWhatsapp = (plus ? '+' : '') + digits;
        },

        normalizeWhatsapp(raw) {
            let digits = String(raw ?? '').replace(/\D/g, '');
            if (!digits) return null;
            if (digits.startsWith('62')) {
                // Sudah format internasional
            } else if (digits.startsWith('0')) {
                digits = '62' + digits.slice(1);
            } else if (digits.startsWith('8')) {
                digits = '62' + digits;
            }
            if (!digits.startsWith('628')) return null;
            if (digits.length < 10 || digits.length > 15) return null;
            return digits;
        },

        get whatsappValid() {
            return this.normalizeWhatsapp(this.visitorWhatsapp) !== null;
        },

        whatsappError() {
            const digits = this.visitorWhatsapp.replace(/\D/g, '');
            if (!digits) return 'Nomor WhatsApp wajib diisi (contoh: 081234567890).';
            if (!digits.startsWith('0') && !digits.startsWith('62') && !digits.startsWith('8')) {
                return 'Nomor WhatsApp harus diawali 08 atau 62 (contoh: 081234567890).';
            }
            return 'Nomor WhatsApp tidak valid. Gunakan 10–15 digit angka, diawali 08 atau 62 (contoh: 081234567890).';
        },

        get canSubmit() {
            if (this.tab === 'unit' && this.selectedUnit && (this.selectedUnit.type === 'glamping' || this.selectedUnit.type === 'aula') && this.checkIn) {
                this.ensureDatesValid();
            }
            if (this.sending || !this.visitorName.trim() || !this.whatsappValid) return false;
            if (this.tab === 'unit') {
                const packaged = this.isPackagedUnit();
                return !!this.selectedUnit && (!packaged || !!this.selectedPackageId) && this.unitSubtotal > 0 && !!this.checkIn && !!this.checkOut && !this.dateInvalid && this.checkIn >= this.todayStr;
            }
            return this.cart.length > 0 && !!this.checkIn && this.checkIn >= this.todayStr;
        },

        typeEmoji(type) {
            return { glamping: '🏕️', aula: '🏛️', alat_wisata: '🥾' }[type] ?? '📦';
        },

        typeLabel(type) {
            return { glamping: 'Glamping', aula: 'Aula', alat_wisata: 'Alat Wisata' }[type] ?? type;
        },

        categoryEmoji(category) {
            return {
                tiket_masuk: '🎫', makanan: '🍜', minuman: '🥤',
                souvenir: '🎁', baju_merchandise: '👕', produk_umkm: '☕',
            }[category] ?? '🛍️';
        },

        formatIDR(value) {
            return 'Rp ' + Math.round(Number(value) || 0).toLocaleString('id-ID');
        },

        csrfToken() {
            return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ?? '';
        },

        async fetchAvailability() {
            this.ensureDatesValid();
            if (!this.checkIn) return;
            if (this.checkIn < this.todayStr) return;
            const packaged = (this.isPackagedUnit() || this.unitType === 'glamping' || this.unitType === 'aula') && this.selectedPackageId;
            if (!packaged && (!this.checkOut || this.dateInvalid)) return;

            const prevSelected = this.selectedUnit ? { ...this.selectedUnit } : null;
            this.loadingUnits = true;
            this.unitsError = '';
            try {
                const params = new URLSearchParams({
                    check_in: this.checkIn,
                    check_in_time: this.checkInTime || (packaged ? '08:00' : '14:00'),
                });
                if (packaged) {
                    params.set('package_id', this.selectedPackageId);
                    const t = this.selectedUnit?.type || (this.unitType === 'aula' ? 'aula' : (this.unitType === 'glamping' ? 'glamping' : null));
                    if (t) params.set('type', t);
                } else {
                    params.set('check_out', this.checkOut);
                    params.set('check_out_time', this.checkOutTime || '12:00');
                }
                const res = await fetch(`/api/availability?${params.toString()}`);
                const data = await res.json();
                if (!res.ok) {
                    this.unitsError = data.message || 'Gagal memuat ketersediaan.';
                    this.availableUnits = [];
                    this.glampingRemainingSlots = null;
                    this.aulaRemainingSlots = null;
                    if (!(prevSelected && (prevSelected.type === 'glamping' || prevSelected.type === 'aula'))) {
                        this.selectedUnit = null;
                    }
                    return;
                }
                this.availableUnits = data.data || [];
                if (Array.isArray(data.glamping_packages)) this.glampingPackages = data.glamping_packages;
                if (Array.isArray(data.aula_packages)) this.aulaPackages = data.aula_packages;
                if (!Array.isArray(data.glamping_packages) && Array.isArray(data.packages)) this.glampingPackages = data.packages;
                this.glampingRemainingSlots = (data.glamping_remaining_slots ?? null);
                this.aulaRemainingSlots = (data.aula_remaining_slots ?? null);

                if (prevSelected) {
                    const found = this.availableUnits.find(u => u.id === prevSelected.id);
                    if (found) {
                        this.selectedUnit = found;
                    } else if ((prevSelected.type === 'glamping' || prevSelected.type === 'aula') && this.selectedPackageId) {
                        const slots = prevSelected.type === 'glamping' ? this.glampingRemainingSlots : this.aulaRemainingSlots;
                        this.selectedUnit = (slots === null || slots > 0) ? prevSelected : null;
                    } else {
                        this.selectedUnit = null;
                    }
                } else {
                    this.selectedUnit = null;
                }

                if (this.selectedUnit && (this.selectedUnit.type === 'glamping' || this.selectedUnit.type === 'aula')) {
                    const pkgs = this.selectedUnit.type === 'aula' ? this.aulaPackages : this.glampingPackages;
                    if (!this.selectedPackageId || !pkgs.find(p => p.id === this.selectedPackageId)) {
                        this.selectedPackageId = pkgs[0]?.id || '';
                    }
                }
            } catch (e) {
                this.unitsError = 'Gagal memuat ketersediaan. Periksa koneksi Anda.';
                if (!(prevSelected && (prevSelected.type === 'glamping' || prevSelected.type === 'aula') && this.selectedPackageId)) {
                    this.selectedUnit = null;
                }
            } finally {
                this.loadingUnits = false;
            }
        },

        selectUnit(unit) {
            this.selectedUnit = unit;
            this.errorMessage = '';
            if (unit.type === 'glamping' || unit.type === 'aula') {
                const pkgs = unit.type === 'aula' ? this.aulaPackages : this.glampingPackages;
                if (!this.selectedPackageId || !pkgs.find(p => p.id === this.selectedPackageId)) {
                    this.selectedPackageId = pkgs[0]?.id || '';
                }
                if (!this.checkIn) this.checkIn = this.todayStr;
                // Jam tidak dipilih user; default internal untuk cek ketersediaan per tanggal/paket.
                this.checkInTime = '08:00';
            } else {
                this.selectedPackageId = '';
                if (!this.checkIn) this.checkIn = this.todayStr;
                if (!this.checkInTime) this.checkInTime = '14:00';
            }
            this.ensureDatesValid();
            if (this.checkIn) this.fetchAvailability();
        },

        onPackageChange() {
            this.errorMessage = '';
            if (this.selectedUnit && !this.isPackagedUnit()) this.selectedUnit = null;
            if ((this.selectedUnit?.type === 'glamping' || this.selectedUnit?.type === 'aula' || this.unitType === 'glamping' || this.unitType === 'aula') && this.selectedPackageId) {
                if (!this.checkIn) this.checkIn = this.todayStr;
                this.checkInTime = '08:00';
            }
            this.ensureDatesValid();
            if (this.checkIn) this.fetchAvailability();
        },

        async loadTickets() {
            this.loadingTickets = true;
            try {
                const res = await fetch('/api/products?category=tiket_masuk&type=addon');
                const data = await res.json();
                this.tickets = data.data || [];
                this.tickets.forEach(t => { this.ticketQuantities[t.id] = 1; });
            } catch (e) {
                this.errorMessage = 'Gagal memuat Tiket Masuk.';
            } finally {
                this.loadingTickets = false;
            }
        },

        async loadAddons() {
            this.loadingAddons = true;
            try {
                const res = await fetch('/api/products?type=addon');
                const data = await res.json();
                this.addons = (data.data || []).filter(p => p.category !== 'tiket_masuk');
            } catch (e) {
                // Add-on bersifat opsional; gagal load tidak memblokir checkout
            } finally {
                this.loadingAddons = false;
            }
        },

        ticketQty(id) {
            return this.ticketQuantities[id] ?? 1;
        },

        incTicketQty(ticket) {
            const current = this.ticketQty(ticket.id);
            if (current < (ticket.stock || 1)) this.ticketQuantities[ticket.id] = current + 1;
        },

        decTicketQty(ticket) {
            const current = this.ticketQty(ticket.id);
            if (current > 1) this.ticketQuantities[ticket.id] = current - 1;
        },

        addTicket(ticket) {
            const qty = this.ticketQty(ticket.id);
            const existing = this.cart.find(i => i.id === ticket.id);
            if (existing) {
                existing.qty = Math.min(existing.qty + qty, ticket.stock);
            } else {
                this.cart.push({ id: ticket.id, name: ticket.name, price: Number(ticket.price), qty, category: 'tiket_masuk' });
            }
            this.errorMessage = '';
        },

        addToCart(product) {
            const existing = this.cart.find(i => i.id === product.id);
            if (existing) {
                if (existing.qty < product.stock) existing.qty += 1;
            } else {
                this.cart.push({ id: product.id, name: product.name, price: Number(product.price), qty: 1, category: product.category });
            }
            this.errorMessage = '';
        },

        openDetail(product, kind = 'addon') {
            this.detailProduct = product;
            this.detailKind = kind;
            this.detailImageIndex = 0;
            this.detailOpen = true;
        },

        closeDetail() {
            this.detailOpen = false;
        },

        prevDetailImage() {
            const n = this.detailImages.length;
            if (!n) return;
            this.detailImageIndex = (this.detailImageIndex - 1 + n) % n;
        },

        nextDetailImage() {
            const n = this.detailImages.length;
            if (!n) return;
            this.detailImageIndex = (this.detailImageIndex + 1) % n;
        },

        detailAdd() {
            if (!this.detailProduct || (this.detailProduct.stock ?? 0) <= 0) return;
            if (this.detailKind === 'tiket') this.addTicket(this.detailProduct);
            else this.addToCart(this.detailProduct);
            this.closeDetail();
        },

        openCheckout() {
            if (this.itemCount === 0) return;
            this.errorMessage = '';
            this.checkoutOpen = true;
        },

        closeCheckout() {
            this.checkoutOpen = false;
        },

        categoryLabel(category) {
            return {
                tiket_masuk: 'Tiket Masuk', makanan: 'Makanan', minuman: 'Minuman',
                souvenir: 'Souvenir', baju_merchandise: 'Baju & Merchandise', produk_umkm: 'Produk UMKM',
            }[category] ?? 'Produk';
        },

        incCart(item) {
            const max = item.category === 'tiket_masuk'
                ? this.tickets.find(t => t.id === item.id)?.stock ?? 99
                : this.addons.find(a => a.id === item.id)?.stock ?? 99;
            if (item.qty < max) item.qty += 1;
        },

        decCart(item) {
            if (item.qty > 1) item.qty -= 1;
        },

        removeCart(item) {
            this.cart = this.cart.filter(i => i.id !== item.id);
        },

        cancelAutoRedirect() {
            if (this.redirectTimer) {
                clearTimeout(this.redirectTimer);
                this.redirectTimer = null;
            }
        },

        resetAll() {
            this.cancelAutoRedirect();
            this.tab = 'unit';
            this.checkIn = '';
            this.checkOut = '';
            this.checkInTime = '14:00';
            this.checkOutTime = '12:00';
            this.unitType = 'all';
            this.availableUnits = [];
            this.selectedUnit = null;
            this.selectedPackageId = '';
            this.tickets = [];
            this.ticketQuantities = {};
            this.cart = [];
            this.visitorName = '';
            this.visitorWhatsapp = '';
            this.detailOpen = false;
            this.detailProduct = null;
            this.detailImageIndex = 0;
            this.checkoutOpen = false;
            this.visitorEmail = '';
            this.errorMessage = '';
            this.success = null;
        },

        async submit() {
            this.ensureDatesValid();
            if (!this.canSubmit) return;
            this.sending = true;
            this.errorMessage = '';
            this.lastTotal = this.grandTotal;

            const unitCheckOut = this.tab === 'unit' ? this.checkOut : null;
            const payload = {
                visitor_name: this.visitorName,
                visitor_whatsapp: this.normalizeWhatsapp(this.visitorWhatsapp) ?? this.visitorWhatsapp,
                visitor_email: this.visitorEmail || null,
                unit_id: this.tab === 'unit' ? this.selectedUnit?.id ?? null : null,
                package_id: (this.tab === 'unit' && this.isPackagedUnit()) ? (this.selectedPackageId || null) : null,
                check_in_date: this.checkIn,
                check_in_time: this.checkInTime,
                check_out_date: unitCheckOut,
                check_out_time: this.checkOutTime,
                addons: this.cart.map(item => ({ product_id: item.id, quantity: item.qty })),
                total_price: this.grandTotal,
            };

            try {
                const res = await fetch('/api/reservations', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': this.csrfToken(),
                    },
                    body: JSON.stringify(payload),
                });
                const data = await res.json();

                if (res.ok && data.success) {
                    this.success = data;
                    this.checkoutOpen = false;
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    this.redirectTimer = setTimeout(() => {
                        window.location.href = '/pembayaran/' + data.order_code;
                    }, 2500);
                } else {
                    this.errorMessage = data.errors?.visitor_whatsapp?.[0]
                        || (data.errors ? Object.values(data.errors).flat()[0] : null)
                        || data.message
                        || 'Gagal membuat pesanan. Coba lagi.';
                }
            } catch (e) {
                this.errorMessage = 'Koneksi gagal. Periksa jaringan Anda.';
            } finally {
                this.sending = false;
            }
        },
    };
}
</script>
@endsection
